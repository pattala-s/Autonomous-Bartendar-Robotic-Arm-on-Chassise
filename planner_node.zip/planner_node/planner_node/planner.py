#!/usr/bin/env python3

import rclpy
import serial
import time
from rclpy.node import Node
from std_msgs.msg import String, Bool
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from cup_interfaces.msg import PoseWithID, PoseWithIDArray

class PlannerNode(Node):
    def __init__(self):
        super().__init__('planner_node')

        # Publishers
        # self.car_motion_pub = self.create_publisher(Twist, '/car_motion', 10)
        self.position_data_pub = self.create_publisher(PoseWithIDArray, '/position_data', 10)
        self.object_pose_pub = self.create_publisher(PoseStamped, '/object/pose', 10)
        self.armspace_status_pub = self.create_publisher(Bool, '/armspace_status', 10)
        # port = '/dev/ttyUSB0'  # Update with your ESP32's serial port
        # baud_rate = 115200
        # timeout = 1

        # try:
        #     # Initialize serial connection
        #     self.ser = serial.Serial(port, baud_rate, timeout=timeout)
        #     time.sleep(2)  # Wait for the connection to initialize
        #     print("✅ Serial connection established.")

        # except serial.SerialException as e:
        #     print(f"Serial connection error: {e}")
        #     self.ser = None  # Important: mark as None to avoid usage later

        # Subscribers
        self.create_subscription(Twist, '/cmd_vel', self.pp_data_callback, 10)
        self.create_subscription(PoseWithIDArray, '/cup_data', self.cup_data_callback, 10)

        # State
        self.armspace_flag = True #false
        self.cup_data_received = False
        self.cup_data_list = []
        self.goal_position = 0

        # Create wait message
        self.wait_msg = Twist()
        self.wait_msg.linear.x = 0.0
        self.wait_msg.linear.y = 0.0

        self.get_logger().info('🚀 Planner Node started successfully!')
    #     self.create_timer(1.0, self.keep_alive)

    # def keep_alive(self):
    #     self.get_logger().debug('🟢 PlannerNode is alive.')

    def send_motor_values(self,ser, motor_values):
        """
        Sends motor values to the ESP32 over serial.
        
        Args:
            ser: The serial connection object.
            motor_values: A list of four integers representing motor values.
        """
        if len(motor_values) != 4:
            raise ValueError("motor_values must contain exactly 4 integers.")
        
        # Convert motor values to a comma-separated string
        data = ','.join(map(str, motor_values)) + '\n'
        ser.write(data.encode('utf-8'))
        print(f"Sent: {data.strip()}")

    def pp_data_callback(self, data):
        self.get_logger().info("Entery for Velocity")
        if self.goal_position <= 350:
            motor_values = [0, 0, 0, 0]
            # # Send motor values
            # self.send_motor_values(self.ser, motor_values)
            self.armspace_flag = True 
        else:
            #New Code here
            motor_values = [data.linear.x, data.linear.y, 0, 0]
            time.sleep(0.5)
            # Send motor values
            # self.send_motor_values(self.ser, motor_values)
            self.get_logger().info("data Sent!")
            self.armspace_flag = True #false

        armspace_msg = Bool()
        armspace_msg.data = self.armspace_flag
        self.armspace_status_pub.publish(armspace_msg)

    def cup_data_callback(self, data):
        
        self.cup_data_list = data.poses  
        for cup in self.cup_data_list:
                # Since this is string data, we just log it
                self.get_logger().info(f'📦 Publishing pose: {cup}')
                # ✅ Check if ID == 4
                if cup.id == 3:
                    
                    print("entered-------------------")
                    self.goal_position= cup.pose.position.z
                    pose_stamped = PoseStamped()
                    pose_stamped.header.stamp = self.get_clock().now().to_msg()
                    pose_stamped.header.frame_id = "camera_link"
                    pose_stamped.pose = cup.pose
                    if cup.pose.position.z >= 400 and cup.pose.position.z <=2000:
                        self.object_pose_pub.publish(pose_stamped)
                        self.get_logger().info(' ID 3 detected and pose published!')
                else:
                    self.goal_position = 0

        
        self.get_logger().info('Data_received!')
        self.cup_data_received = True
        self.publish_arm_motion()

    def publish_arm_motion(self):
        if self.cup_data_received:
            # Publish position data
            msg = PoseWithIDArray()
            msg.poses = self.cup_data_list
            self.position_data_pub.publish(msg)
            self.get_logger().info('Data Published to position_data')
            all_ids = [int(cup.id) for cup in msg.poses]
            self.get_logger().info(f"All IDs in message: {all_ids}")

            # Reset flag
            self.cup_data_received = True #false
    
    # def destroy_node(self):
    #     super().destroy_node()
    #     if self.ser is not None and self.ser.is_open:
    #         self.ser.close()
    #         self.get_logger().info("🧩 Serial connection closed.")

def main(args=None):
    rclpy.init(args=args)
    node = PlannerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()







# #!/usr/bin/env python3

# import rclpy
# from rclpy.node import Node
# from std_msgs.msg import String, Bool
# from geometry_msgs.msg import Twist
# from geometry_msgs.msg import PoseStamped
# from cup_interfaces.msg import PoseWithID, PoseWithIDArray

# class PlannerNode(Node):
#     def __init__(self):
#         super().__init__('planner_node')

#         # Publishers
#         self.car_motion_pub = self.create_publisher(Twist, '/car_motion', 10)
#         self.position_data_pub = self.create_publisher(PoseWithIDArray, '/position_data', 10)
#         self.object_pose_pub = self.create_publisher(PoseStamped, '/object/pose', 10)
#         self.armspace_status_pub = self.create_publisher(Bool, '/armspace_status', 10)

#         # Subscribers
#         self.create_subscription(Twist, '/cmd_vel', self.pp_data_callback, 10)
#         self.create_subscription(PoseWithIDArray, '/cup_data', self.cup_data_callback, 10)

#         # State
#         self.armspace_flag = True
#         self.cup_data_received = False
#         self.cup_data_list = []

#         # Create wait message
#         self.wait_msg = Twist()
#         self.wait_msg.linear.x = 0.0
#         self.wait_msg.linear.y = 0.0

#         self.get_logger().info('🚀 Planner Node started successfully!')

#     def pp_data_callback(self, data):
#         goal_position = data.angular.z
#         if goal_position < 0.15:
#             self.car_motion_pub.publish(self.wait_msg)
#             self.armspace_flag = True 
#         else:
#             self.car_motion_pub.publish(data)
#             self.get_logger().info(data)
#             self.armspace_flag = True

#         armspace_msg = Bool()
#         armspace_msg.data = self.armspace_flag
#         self.armspace_status_pub.publish(armspace_msg)

#     def cup_data_callback(self, data):
        
#         self.cup_data_list = data.poses  
#         for cup in self.cup_data_list:
#                 # Since this is string data, we just log it
#                 self.get_logger().info(f'📦 Publishing pose: {cup}')
#                 # ✅ Check if ID == 4
#                 if cup.id == 3:
#                     print("entered-------------------")
#                     pose_stamped = PoseStamped()
#                     pose_stamped.header.stamp = self.get_clock().now().to_msg()
#                     pose_stamped.header.frame_id = "camera_link"
#                     pose_stamped.pose = cup.pose
#                     self.object_pose_pub.publish(pose_stamped)
#                     self.get_logger().info(' ID 3 detected and pose published!')

        
#         self.get_logger().info('Data_received!')
#         self.cup_data_received = True
#         self.publish_arm_motion()

#     def publish_arm_motion(self):
#         if self.cup_data_received:
#             # Publish position data
#             msg = PoseWithIDArray()
#             msg.poses = self.cup_data_list
#             self.position_data_pub.publish(msg)
#             self.get_logger().info('Data Published to position_data')
#             all_ids = [int(cup.id) for cup in msg.poses]
#             self.get_logger().info(f"All IDs in message: {all_ids}")

#             # Reset flag
#             self.cup_data_received = True

# def main(args=None):
#     rclpy.init(args=args)
#     node = PlannerNode()
#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         pass
#     node.destroy_node()
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()
