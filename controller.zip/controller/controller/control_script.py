import sys
import time
import numpy as np

import rclpy
from rclpy.node import Node
from cup_interfaces.msg import PoseWithIDArray, PoseWithID

# from interbotix_common_modules.common_robot.robot import robot_shutdown
from interbotix_xs_modules.xs_robot.arm import InterbotixManipulatorXS


class ReactorX200Controller(Node):
    def __init__(self):
        super().__init__('reactorx200_controller')

        # Initialize robot
        self.bot = InterbotixManipulatorXS("rx200", "arm", "gripper")
        if self.bot.arm.group_info.num_joints < 5:
            self.get_logger().error('This demo requires the robot to have at least 5 joints!')
            sys.exit()

        # Subscriber to cup poses topic
        self.subscription = self.create_subscription(
            PoseWithIDArray,
            '/position_data',
            self.pose_callback,
            10
        )

        # Track cup positions and processed IDs
        self.cup_positions = {}  # {id: (x, y, z)}
        self.processed_ids = set()  # ✅ Track processed cup IDs

        self.get_logger().info('🍹 ReactorX200 Controller Node started successfully!')

    def move_to_pose(self, x2, y2, z2):
        # Camera to EE transform (fixed)
        x1, y1, z1 = -0.115, 0, 0.07
        R1 = np.eye(3)
        # R1 = np.array([[0, 0, 1], [-1, 0, 0], [0, -1, 0]])
        # R1 = np.array([[-1, 0, 0], [0, -1, 0], [0, 0, -1]])
        t1 = np.array([[x1], [y1], [z1]])
        ee_T_c = np.vstack((np.hstack((R1, t1)), np.array([[0, 0, 0, 1]])))

        # EE pose w.r.t Base frame
        b_T_ee = self.bot.arm.get_ee_pose()

        x2 = x2/1000
        y2 = y2/1000
        z2 = z2/1000

        print("x",x2, "y",y2,"z",z2)
        
        # Camera to Object transform
        R2 = np.eye(3)
        t2 = np.array([[x2], [y2], [z2]])
        c_T_o = np.vstack((np.hstack((R2, t2)), np.array([[0, 0, 0, 1]])))

        # Final transformation: Object to Base frame
        b_T_o = np.dot(np.dot(b_T_ee, ee_T_c), c_T_o)

        x, y, z = b_T_o[0, 3], b_T_o[1, 3], b_T_o[2, 3]
        


        self.get_logger().info(f'🤖 Moving to pose: x={x:.3f}, y={y:.3f}, z={z:.3f}')
        # self.bot.arm.set_ee_pose_components(x,y,z)
        # self.bot.arm.set_ee_pose_matrix(b_T_o)
        time.sleep(2)
        print("xz done")
        self.bot.arm.set_ee_pose_components(x=x,z=z)
        print("y done")
        



    def pour_action(self):
        self.get_logger().info('🍶 Performing pour action...')
        self.bot.arm.set_single_joint_position('wrist_angle', 1.0)
        time.sleep(2)
        self.bot.arm.set_single_joint_position('wrist_angle', 0.0)
        self.get_logger().info('✅ Pour action completed.')

    def handle_cup_task(self, cup_id, pour_target_pose):
        if cup_id not in self.cup_positions:
            self.get_logger().warn(f'❌ Cup ID {cup_id} not found in detected poses.')
            return
        
        # Step 1: Home Position
        x_h, y_h, z_h = 0.2, 0, 0.2
        self.bot.arm.set_ee_pose_components(x_h, y_h, z_h)
        time.sleep(1)
        print("Home position done")


        
        # Step 1: Move to cup location
        cup_pose = self.cup_positions[cup_id]
        print("current_pose", self.bot.arm.get_ee_pose() )
        print("goal_pose_before",*cup_pose )
        time.sleep(3)
        self.get_logger().info(f'🚚 Moving to pick up cup ID {cup_id}')
        self.move_to_pose(*cup_pose)
        print("Move done")

        

        # Step 2: Grasp the cup
        self.bot.gripper.grasp()
        time.sleep(1)

        # Step 3: Lift up
        self.bot.arm.set_ee_cartesian_trajectory(x_h, y_h, z_h)
        time.sleep(1)

        

        # Step 4: Move to pour location (offset of ID 1)
        self.get_logger().info(f'🚚 Moving to pour at ID 1 location with offset')
        self.move_to_pose(*pour_target_pose)
        time.sleep(1)

        # Step 5: Pour action
        self.pour_action()

        # # Step 6: Return to original cup location
        # self.get_logger().info(f'🚚 Returning cup ID {cup_id} to original location')
        # self.move_to_pose(*cup_pose)
        # time.sleep(1)

        # # Step 7: Release the cup
        # self.bot.gripper.release()
        # time.sleep(1)

        # # Step 8: Lift up
        # self.bot.arm.set_ee_cartesian_trajectory(x=0, z=0.15)

        self.get_logger().info(f'✅ Completed task for cup ID {cup_id}')

        # ✅ Mark this cup ID as processed!
        self.processed_ids.add(cup_id)

    def pose_callback(self, msg):
        # Update all cup positions
        self.cup_positions = {
            cup.id: (cup.pose.position.x, cup.pose.position.y, cup.pose.position.z)
            for cup in msg.poses
        }

        self.get_logger().info(f'✅ Received cup positions: {self.cup_positions}')

        # Check if required ID 1 is present (base pour position)
        if 1 not in self.cup_positions:
            self.get_logger().warn(f'⚠️ Cup ID 1 not found. Skipping tasks.')
            return

        # Define pour target pose based on ID 1 location
        base_pour_pose = self.cup_positions[1]
        pour_pose = (
            base_pour_pose[0],
            base_pour_pose[1] + 0.05,
            base_pour_pose[2] + 0.1
        )

        # Process cups only once
        for cup_id in [2, 3]:
            if cup_id in self.cup_positions and cup_id not in self.processed_ids:
                self.handle_cup_task(cup_id, pour_pose)

    # def destroy_node(self):
    #     super().destroy_node()
    #     self.bot.shutdown()

    #def destroy_node(self):
     #   super().destroy_node()
      #  robot_shutdown(self.bot)

def main(args=None):
    rclpy.init(args=args)
    node = ReactorX200Controller()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('👋 Shutdown requested. Exiting...')
    finally:
        # node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
