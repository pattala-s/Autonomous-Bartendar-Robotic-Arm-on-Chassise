import rclpy
from rclpy.node import Node
from moveit_commander import MoveGroupCommander, PlanningSceneInterface, RobotCommander
from geometry_msgs.msg import Pose

class MoveItCommanderNode(Node):
    def __init__(self):
        super().__init__('moveit_commander_node')

        # Initialize RobotCommander (overall robot information)
        self.robot = RobotCommander()

        # Initialize PlanningSceneInterface (environment representation)
        self.scene = PlanningSceneInterface()

        # Initialize MoveGroupCommander for your arm group (usually "arm")
        self.group = MoveGroupCommander("arm")

        # Info
        self.get_logger().info("🚀 MoveIt Commander Node Initialized!")

    def move_to_pose(self):
        # Define target pose
        target_pose = Pose()
        target_pose.position.x = 0.3
        target_pose.position.y = 0.0
        target_pose.position.z = 0.2
        target_pose.orientation.w = 1.0

        # Set the target pose
        self.group.set_pose_target(target_pose)

        # Plan and execute
        plan = self.group.go(wait=True)

        # Call stop() to prevent residual movement
        self.group.stop()

        # Clear targets after planning with poses
        self.group.clear_pose_targets()

        self.get_logger().info(f"✅ Movement execution status: {plan}")

def main(args=None):
    rclpy.init(args=args)
    node = MoveItCommanderNode()

    # Move to target pose
    node.move_to_pose()

    # Shutdown
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

