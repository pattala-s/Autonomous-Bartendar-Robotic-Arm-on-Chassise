// generated from rosidl_generator_c/resource/idl.h.em
// with input from cup_interfaces:msg/CupPose.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__CUP_POSE_H_
#define CUP_INTERFACES__MSG__CUP_POSE_H_

#include "cup_interfaces/msg/detail/cup_pose__struct.h"
#include "cup_interfaces/msg/detail/cup_pose__functions.h"
#include "cup_interfaces/msg/detail/cup_pose__type_support.h"

#endif  // CUP_INTERFACES__MSG__CUP_POSE_H_
