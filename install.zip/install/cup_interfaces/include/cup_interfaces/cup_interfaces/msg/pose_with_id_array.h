// generated from rosidl_generator_c/resource/idl.h.em
// with input from cup_interfaces:msg/PoseWithIDArray.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__POSE_WITH_ID_ARRAY_H_
#define CUP_INTERFACES__MSG__POSE_WITH_ID_ARRAY_H_

#include "cup_interfaces/msg/detail/pose_with_id_array__struct.h"
#include "cup_interfaces/msg/detail/pose_with_id_array__functions.h"
#include "cup_interfaces/msg/detail/pose_with_id_array__type_support.h"

#endif  // CUP_INTERFACES__MSG__POSE_WITH_ID_ARRAY_H_
