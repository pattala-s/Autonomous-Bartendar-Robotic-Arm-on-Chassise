// generated from rosidl_generator_c/resource/idl.h.em
// with input from cup_interfaces:msg/PoseWithID.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__POSE_WITH_ID_H_
#define CUP_INTERFACES__MSG__POSE_WITH_ID_H_

#include "cup_interfaces/msg/detail/pose_with_id__struct.h"
#include "cup_interfaces/msg/detail/pose_with_id__functions.h"
#include "cup_interfaces/msg/detail/pose_with_id__type_support.h"

#endif  // CUP_INTERFACES__MSG__POSE_WITH_ID_H_
