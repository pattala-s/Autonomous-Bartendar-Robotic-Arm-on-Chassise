// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from cup_interfaces:msg/PoseWithIDArray.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__STRUCT_H_
#define CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'poses'
#include "cup_interfaces/msg/detail/pose_with_id__struct.h"

/// Struct defined in msg/PoseWithIDArray in the package cup_interfaces.
typedef struct cup_interfaces__msg__PoseWithIDArray
{
  cup_interfaces__msg__PoseWithID__Sequence poses;
} cup_interfaces__msg__PoseWithIDArray;

// Struct for a sequence of cup_interfaces__msg__PoseWithIDArray.
typedef struct cup_interfaces__msg__PoseWithIDArray__Sequence
{
  cup_interfaces__msg__PoseWithIDArray * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} cup_interfaces__msg__PoseWithIDArray__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__STRUCT_H_
