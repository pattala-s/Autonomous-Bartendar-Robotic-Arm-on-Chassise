// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from cup_interfaces:msg/PoseWithID.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID__BUILDER_HPP_
#define CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "cup_interfaces/msg/detail/pose_with_id__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace cup_interfaces
{

namespace msg
{

namespace builder
{

class Init_PoseWithID_pose
{
public:
  explicit Init_PoseWithID_pose(::cup_interfaces::msg::PoseWithID & msg)
  : msg_(msg)
  {}
  ::cup_interfaces::msg::PoseWithID pose(::cup_interfaces::msg::PoseWithID::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cup_interfaces::msg::PoseWithID msg_;
};

class Init_PoseWithID_id
{
public:
  Init_PoseWithID_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PoseWithID_pose id(::cup_interfaces::msg::PoseWithID::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_PoseWithID_pose(msg_);
  }

private:
  ::cup_interfaces::msg::PoseWithID msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::cup_interfaces::msg::PoseWithID>()
{
  return cup_interfaces::msg::builder::Init_PoseWithID_id();
}

}  // namespace cup_interfaces

#endif  // CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID__BUILDER_HPP_
