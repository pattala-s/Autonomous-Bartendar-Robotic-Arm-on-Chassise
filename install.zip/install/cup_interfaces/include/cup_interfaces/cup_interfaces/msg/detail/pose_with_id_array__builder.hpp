// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from cup_interfaces:msg/PoseWithIDArray.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__BUILDER_HPP_
#define CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "cup_interfaces/msg/detail/pose_with_id_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace cup_interfaces
{

namespace msg
{

namespace builder
{

class Init_PoseWithIDArray_poses
{
public:
  Init_PoseWithIDArray_poses()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::cup_interfaces::msg::PoseWithIDArray poses(::cup_interfaces::msg::PoseWithIDArray::_poses_type arg)
  {
    msg_.poses = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cup_interfaces::msg::PoseWithIDArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::cup_interfaces::msg::PoseWithIDArray>()
{
  return cup_interfaces::msg::builder::Init_PoseWithIDArray_poses();
}

}  // namespace cup_interfaces

#endif  // CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__BUILDER_HPP_
