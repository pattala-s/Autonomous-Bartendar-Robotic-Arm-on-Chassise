// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from cup_interfaces:msg/CupPose.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__CUP_POSE__BUILDER_HPP_
#define CUP_INTERFACES__MSG__DETAIL__CUP_POSE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "cup_interfaces/msg/detail/cup_pose__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace cup_interfaces
{

namespace msg
{

namespace builder
{

class Init_CupPose_pose
{
public:
  explicit Init_CupPose_pose(::cup_interfaces::msg::CupPose & msg)
  : msg_(msg)
  {}
  ::cup_interfaces::msg::CupPose pose(::cup_interfaces::msg::CupPose::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cup_interfaces::msg::CupPose msg_;
};

class Init_CupPose_id
{
public:
  Init_CupPose_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CupPose_pose id(::cup_interfaces::msg::CupPose::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_CupPose_pose(msg_);
  }

private:
  ::cup_interfaces::msg::CupPose msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::cup_interfaces::msg::CupPose>()
{
  return cup_interfaces::msg::builder::Init_CupPose_id();
}

}  // namespace cup_interfaces

#endif  // CUP_INTERFACES__MSG__DETAIL__CUP_POSE__BUILDER_HPP_
