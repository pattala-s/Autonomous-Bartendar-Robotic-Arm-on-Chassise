// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from cup_interfaces:msg/CupPose.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__CUP_POSE__TYPE_SUPPORT_H_
#define CUP_INTERFACES__MSG__DETAIL__CUP_POSE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "cup_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_cup_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  cup_interfaces,
  msg,
  CupPose
)();

#ifdef __cplusplus
}
#endif

#endif  // CUP_INTERFACES__MSG__DETAIL__CUP_POSE__TYPE_SUPPORT_H_
