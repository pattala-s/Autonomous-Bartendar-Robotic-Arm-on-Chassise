// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from cup_interfaces:msg/CupPose.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__CUP_POSE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define CUP_INTERFACES__MSG__DETAIL__CUP_POSE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "cup_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_cup_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cup_interfaces, msg, CupPose)();

#ifdef __cplusplus
}
#endif

#endif  // CUP_INTERFACES__MSG__DETAIL__CUP_POSE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
