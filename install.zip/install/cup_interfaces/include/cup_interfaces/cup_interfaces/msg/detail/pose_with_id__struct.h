// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from cup_interfaces:msg/PoseWithID.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID__STRUCT_H_
#define CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"

/// Struct defined in msg/PoseWithID in the package cup_interfaces.
typedef struct cup_interfaces__msg__PoseWithID
{
  int32_t id;
  geometry_msgs__msg__Pose pose;
} cup_interfaces__msg__PoseWithID;

// Struct for a sequence of cup_interfaces__msg__PoseWithID.
typedef struct cup_interfaces__msg__PoseWithID__Sequence
{
  cup_interfaces__msg__PoseWithID * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} cup_interfaces__msg__PoseWithID__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID__STRUCT_H_
