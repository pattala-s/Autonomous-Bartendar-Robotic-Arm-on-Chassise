// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from cup_interfaces:msg/CupPose.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__CUP_POSE__STRUCT_H_
#define CUP_INTERFACES__MSG__DETAIL__CUP_POSE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose_stamped__struct.h"

/// Struct defined in msg/CupPose in the package cup_interfaces.
typedef struct cup_interfaces__msg__CupPose
{
  int32_t id;
  geometry_msgs__msg__PoseStamped pose;
} cup_interfaces__msg__CupPose;

// Struct for a sequence of cup_interfaces__msg__CupPose.
typedef struct cup_interfaces__msg__CupPose__Sequence
{
  cup_interfaces__msg__CupPose * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} cup_interfaces__msg__CupPose__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUP_INTERFACES__MSG__DETAIL__CUP_POSE__STRUCT_H_
