// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from cup_interfaces:msg/PoseWithIDArray.idl
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__STRUCT_HPP_
#define CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'poses'
#include "cup_interfaces/msg/detail/pose_with_id__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__cup_interfaces__msg__PoseWithIDArray __attribute__((deprecated))
#else
# define DEPRECATED__cup_interfaces__msg__PoseWithIDArray __declspec(deprecated)
#endif

namespace cup_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PoseWithIDArray_
{
  using Type = PoseWithIDArray_<ContainerAllocator>;

  explicit PoseWithIDArray_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
  }

  explicit PoseWithIDArray_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
    (void)_alloc;
  }

  // field types and members
  using _poses_type =
    std::vector<cup_interfaces::msg::PoseWithID_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<cup_interfaces::msg::PoseWithID_<ContainerAllocator>>>;
  _poses_type poses;

  // setters for named parameter idiom
  Type & set__poses(
    const std::vector<cup_interfaces::msg::PoseWithID_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<cup_interfaces::msg::PoseWithID_<ContainerAllocator>>> & _arg)
  {
    this->poses = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator> *;
  using ConstRawPtr =
    const cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__cup_interfaces__msg__PoseWithIDArray
    std::shared_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__cup_interfaces__msg__PoseWithIDArray
    std::shared_ptr<cup_interfaces::msg::PoseWithIDArray_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PoseWithIDArray_ & other) const
  {
    if (this->poses != other.poses) {
      return false;
    }
    return true;
  }
  bool operator!=(const PoseWithIDArray_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PoseWithIDArray_

// alias to use template instance with default allocator
using PoseWithIDArray =
  cup_interfaces::msg::PoseWithIDArray_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace cup_interfaces

#endif  // CUP_INTERFACES__MSG__DETAIL__POSE_WITH_ID_ARRAY__STRUCT_HPP_
