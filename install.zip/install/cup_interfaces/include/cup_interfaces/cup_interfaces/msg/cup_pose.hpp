// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__CUP_POSE_HPP_
#define CUP_INTERFACES__MSG__CUP_POSE_HPP_

#include "cup_interfaces/msg/detail/cup_pose__struct.hpp"
#include "cup_interfaces/msg/detail/cup_pose__builder.hpp"
#include "cup_interfaces/msg/detail/cup_pose__traits.hpp"
#include "cup_interfaces/msg/detail/cup_pose__type_support.hpp"

#endif  // CUP_INTERFACES__MSG__CUP_POSE_HPP_
