// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUP_INTERFACES__MSG__POSE_WITH_ID_HPP_
#define CUP_INTERFACES__MSG__POSE_WITH_ID_HPP_

#include "cup_interfaces/msg/detail/pose_with_id__struct.hpp"
#include "cup_interfaces/msg/detail/pose_with_id__builder.hpp"
#include "cup_interfaces/msg/detail/pose_with_id__traits.hpp"
#include "cup_interfaces/msg/detail/pose_with_id__type_support.hpp"

#endif  // CUP_INTERFACES__MSG__POSE_WITH_ID_HPP_
